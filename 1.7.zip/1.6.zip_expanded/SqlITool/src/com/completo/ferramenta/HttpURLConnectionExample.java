package com.completo.ferramenta;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;

import com.report.csv.GenerateCSV;
import com.vulnerabiliite.injection.SQLI.*;


public class HttpURLConnectionExample {
	
	
   public static final String ANSI_RESET = "\u001B[0m";
   public static final String ANSI_BLACK = "\u001B[30m";
   public static final String ANSI_RED = "\u001B[31m";
   public static final String ANSI_GREEN = "\u001B[32m";
   public static final String ANSI_YELLOW = "\u001B[33m";
   public static final String ANSI_BLUE = "\u001B[34m";
   public static final String ANSI_PURPLE = "\u001B[35m";
   public static final String ANSI_CYAN = "\u001B[36m";
   public static final String ANSI_WHITE = "\u001B[37m";
	//Mac Agent
	private final String USER_AGENT = "Mozilla/5.0";
	public static void main(String[] args) throws Exception {
		
		Scanner scanMe = new Scanner(System.in);
		
		 String url = scanMe.nextLine();
		HttpURLConnectionExample http = new HttpURLConnectionExample();
		/*System.out.println("Testing 1 - Send Http GET request");
		http.sendGet();*/
		GenerateCSV gen =  new GenerateCSV();
		gen.genetateCSV();
		http.sendPost(url);
		
		/*System.out.println(ANSI_WHITE +"0000000 88888888 $$$	=========   2222      22");
		System.out.println(ANSI_WHITE+"00	88    88 $$$  	  =====     22 22     22");
		System.out.println(ANSI_WHITE+"00      88    88 $$$  	  |||||     22  22    22");
		System.out.println(ANSI_WHITE+"0000000 88888888 $$$      |||||     22   22   22");
		System.out.println(ANSI_WHITE+"     00       88 $$$       |||      22    22  22");
		System.out.println(ANSI_WHITE+"     00       88 $$$        V       22     22 22");
		System.out.println(ANSI_WHITE+"0000000       88 $$$$$$$$   |       22      2222");
		
		//Checking malicious input
		/*if(args[0] == "") {
			System.out.println("Invalid Target");
		}
		else if(args[0].matches("https?:\\/\\/(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)")) {
			System.out.println("Executing attack...");
			http.sendPost(url);
			System.exit(0);
		}else {
			System.exit(0);
		}
		
*/
		
		
	}
	
	public static int fileCountSQL() throws IOException {
		LineCount count =  new LineCount();
		String queries = "SqlITool/src/queries";
		int fileCount = count.coutLine(queries);
		return fileCount;	
	}
	private void sendPost(String url) throws Exception {
		int count =  fileCountSQL();
		for(int i = 0 ; i< count ; i++) {
	
		URL obj = new URL(url);
		HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
		//add reuqest header
				con.setRequestMethod("POST");
				con.setRequestProperty("User-Agent", USER_AGENT);
				con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			String line = Files.readAllLines(Paths.get("SqlITool/src/queries")).get(i);
			String urlParameters = line;
		//read file into stream, try-with-resources
		//Send post request
		con.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes(urlParameters);
		wr.flush();
		wr.close();
		int responseCode = con.getResponseCode();
		System.out.println("----------------------------------------------------------------");
		System.out.println("Response Code: "+responseCode + " <------> " + "<--->" + url + " <---->" + urlParameters);
		System.out.println("----------------------------------------------------------------");
	BufferedReader in = new BufferedReader(
		new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
		if(responseCode == 200) {
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
			SQLI input = new SQLI();
			input.SQLI(response.toString(), url, urlParameters );
		}
			SQLI op = new SQLI();
			op.MySqlError();
			op.Microsoft();
			op.Postgre();
			op.Oracle();
		}
		
				
		
		
		System.out.println("Scanner ended...");
		in.close();
	}	
   }
}