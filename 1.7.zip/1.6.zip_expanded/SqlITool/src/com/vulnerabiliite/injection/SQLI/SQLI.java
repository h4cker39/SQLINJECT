package com.vulnerabiliite.injection.SQLI;



import com.report.*;
import com.report.csv.GenerateCSV;

import java.util.ArrayList;

public class SQLI {
	
	   public static final String ANSI_RESET = "\u001B[0m";
	   public static final String ANSI_BLACK = "\u001B[30m";
	   public static final String ANSI_RED = "\u001B[31m";
	   public static final String ANSI_GREEN = "\u001B[32m";
	   public static final String ANSI_YELLOW = "\u001B[33m";
	   public static final String ANSI_BLUE = "\u001B[34m";
	   public static final String ANSI_PURPLE = "\u001B[35m";
	   public static final String ANSI_CYAN = "\u001B[36m";
	   public static final String ANSI_WHITE = "\u001B[37m";
	   public static ArrayList<String> wordArrayList = new ArrayList<String>();
	   public static String url = "";
	   int count = 0;
	   public static String querie = "";
	//Constructor to check for vulnerabilities....
	public SQLI() {
		super();
	}
	public void SQLI(String input, String url, String querie) {
		this.url = url;
		this.querie = querie;
		for(String word : input.split(" ")) {
		    wordArrayList.add(word);
		}
	
	}
	public String getQuerie() {
		return querie;
	}
	
	public String getUrl() {
		return  url ;
	}
public void MySqlError() {	
		
	int localCount = 0;
		for(int i = 0 ;i<wordArrayList.size() ; i++) {
			if(wordArrayList.get(i).equals("error") || wordArrayList.get(i).equals("syntax;")|| wordArrayList.get(i).equals("SQL")
					|| wordArrayList.get(i) == ("manual") || wordArrayList.get(i).equals("MySQL") || wordArrayList.get(i).equals("server")) {
				
			localCount++;
			
			GenerateCSV gen =  new GenerateCSV();
			gen.appendToFile( getUrl() , getQuerie());
			}
		}
		System.out.println(ANSI_GREEN + " Total MySql vulnerabilities found until now " + localCount);
	}	
public void Postgre() {	
	// Query failed: ERROR: syntax error at or near
	
	int localCount = 0 ;
	for(int i = 0 ;i<wordArrayList.size() ; i++) {
		if(wordArrayList.get(i).equals("Query") || wordArrayList.get(i).equals("failed:")|| wordArrayList.get(i).equals("ERROR:")){
		localCount ++;
		GenerateCSV gen =  new GenerateCSV();
		gen.appendToFile(url, querie);
		
		}
	}
	System.out.println(ANSI_BLUE + " Total Postgre DB vulnerabilities found until now "+ localCount);
}	
public void Microsoft() {	
	int localCount = 0;
	 //Microsoft SQLNative Client error
	for(int i = 0 ;i<wordArrayList.size() ; i++) {
		if(wordArrayList.get(i).equals("Microsoft") || wordArrayList.get(i).equals("SQLNative;")|| wordArrayList.get(i).equals("Client")){ 
			localCount ++;
			GenerateCSV gen =  new GenerateCSV();
			gen.appendToFile(url, querie);
		}
	}
	System.out.println(ANSI_YELLOW + " Total Microsoft SQLNative DB vulnerabilities found until now "+ localCount);
}	
public void Oracle() {	
	//ORA-00933: SQL command not properly ended
	int localCount  = 0;
	for(int i = 0 ;i<wordArrayList.size() ; i++) {
		if((wordArrayList.get(i).equals("ORA-00933:") || wordArrayList.get(i).equals("command"))
				|| wordArrayList.get(i).equals("command")) {
			localCount ++;
			GenerateCSV gen =  new GenerateCSV();
			gen.appendToFile(url, querie);
		}
	}
	System.out.println(ANSI_RED + " Total Oracle DB vulnerabilities found until now "+ localCount);
	}
}
	
	

	
