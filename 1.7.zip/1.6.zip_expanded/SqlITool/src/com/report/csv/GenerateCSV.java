package com.report.csv;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GenerateCSV {
	
	public static String fileName = "";
	public static  PrintWriter pw ;
	
	public void genetateCSV() throws FileNotFoundException {
		Scanner scan =  new Scanner(System.in);
		System.out.println("PLease type in the name of the file");
		String fileName = scan.nextLine();
		 pw = new PrintWriter(new File("/home/luisgio/" + fileName));
	}
	public void appendToFile(String url, String querie) {
		
		System.out.println( " ----" +  url +" ------- "+ querie);
		int id  = 0 ; 
		StringBuilder sb  =  new StringBuilder();
		sb.append(id ++);
		sb.append(",");
		sb.append(url);
		sb.append(",");
		sb.append(querie);
		sb.append("/n");
	
		System.out.println(sb.toString());
		pw.write(sb.toString());
		pw.close();
		System.out.println("Appended to report");
	}
	public void finale() {
		System.out.println("Ended");
	}
	
}
